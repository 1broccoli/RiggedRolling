-- Create the main frame
local frame = CreateFrame("Frame", "RiggedRollingFrame", UIParent, "BackdropTemplate")
frame:SetSize(150, 200)
frame:SetPoint("CENTER")
frame:SetMovable(true)
frame:EnableMouse(true)
frame:RegisterForDrag("LeftButton")
frame:SetScript("OnDragStart", frame.StartMoving)
frame:SetScript("OnDragStop", frame.StopMovingOrSizing)

-- Set the backdrop
frame:SetBackdrop({
    bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
    edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
    tile = true, tileSize = 32, edgeSize = 32,
    insets = { left = 8, right = 8, top = 8, bottom = 8 }
})
frame:SetBackdropColor(0, 0, 0, 0.8)

-- Title text
local title = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlightLarge")
title:SetPoint("TOPLEFT", frame, "TOPLEFT", 20, -10)
title:SetText("Rigged Rolling")
title:SetTextColor(0, 1, 1)  -- Cyan color

-- Input boxes and labels
local inputBoxWidth = 50
local inputBoxHeight = 30
local labelOffset = 2
local boxSpacing = 10

-- Left input box (for the lower bound of the range)
local leftInputBox = CreateFrame("EditBox", nil, frame, "InputBoxTemplate")
leftInputBox:SetSize(inputBoxWidth, inputBoxHeight)
leftInputBox:SetPoint("TOPLEFT", frame, "TOPLEFT", 20, -50)
leftInputBox:SetAutoFocus(false)
leftInputBox:SetMaxLetters(4)
leftInputBox:SetNumeric(true)
leftInputBox:SetText("1") -- Default value

-- Label for the left input box
local leftLabel = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
leftLabel:SetPoint("BOTTOM", leftInputBox, "TOP", 0, labelOffset)
leftLabel:SetText("Min")
leftLabel:SetTextColor(0, 1, 1)  -- Cyan color

-- Right input box (for the upper bound of the range)
local rightInputBox = CreateFrame("EditBox", nil, frame, "InputBoxTemplate")
rightInputBox:SetSize(inputBoxWidth, inputBoxHeight)
rightInputBox:SetPoint("LEFT", leftInputBox, "RIGHT", boxSpacing, 0)
rightInputBox:SetAutoFocus(false)
rightInputBox:SetMaxLetters(4)
rightInputBox:SetNumeric(true)
rightInputBox:SetText("100") -- Default value

-- Label for the right input box
local rightLabel = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
rightLabel:SetPoint("BOTTOM", rightInputBox, "TOP", 0, labelOffset)
rightLabel:SetText("Max")
rightLabel:SetTextColor(0, 1, 1)  -- Cyan color

-- Dash label between input boxes
local dashLabel = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
dashLabel:SetPoint("CENTER", leftInputBox, "CENTER", inputBoxWidth + boxSpacing / 2, 0)
dashLabel:SetText("-")
dashLabel:SetTextColor(0, 1, 1)  -- Cyan color

-- Original input box (for the user's entered number)
local inputBox = CreateFrame("EditBox", nil, frame, "InputBoxTemplate")
inputBox:SetSize(100, inputBoxHeight)
inputBox:SetPoint("TOPLEFT", frame, "TOPLEFT", 20, -100)
inputBox:SetAutoFocus(false)
inputBox:SetMaxLetters(4)
inputBox:SetNumeric(true)

-- Label for the original input box
local inputLabel = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
inputLabel:SetPoint("BOTTOM", inputBox, "TOP", 0, labelOffset)
inputLabel:SetText("Roll")
inputLabel:SetTextColor(0, 1, 1)  -- Cyan color

-- Button
local button = CreateFrame("Button", nil, frame, "GameMenuButtonTemplate")
button:SetSize(100, inputBoxHeight)
button:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 20, 20)
button:SetText("Riggit")

-- Function to handle button click
button:SetScript("OnClick", function()
    local number = inputBox:GetText() -- Get the number entered in the input box
    local minRoll = tonumber(leftInputBox:GetText()) -- Get the lower bound of the roll
    local maxRoll = tonumber(rightInputBox:GetText()) -- Get the upper bound of the roll
    local playerName = UnitName("player") -- Get the player's name

    -- Validate input
    if number ~= "" and minRoll and maxRoll and minRoll < maxRoll then
        local roll = math.random(minRoll, maxRoll)
        -- Print the message in the chat in yellow text
        local message = string.format("|cffffff00%s rolls %s (%d-%d)|r", playerName, number, minRoll, maxRoll)
        print(message)  -- Prints to the player's chat window
    else
        -- Print an error message in red if input is invalid
        print("|cffff0000Please enter a valid number and range.|r")
    end
end)
